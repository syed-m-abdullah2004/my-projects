from datetime import datetime
class account:
    def __init__(self,acc_no,bal):
        self.acc_no=acc_no
        self.bal=bal
        print("Your account no is : ",self.acc_no)
        print("Your balance is  : ",self.bal)
    def debit(self):
        amount=int(input("Enter the amount to withdraw" ))
        self.bal-=amount
        print("Your balance is : ",self.bal)
    def credit(self):
        amount=int(input("Enter the amount to add" ))
        self.bal+=amount 
        print("Your balance is : ",self.bal)
    def stat(self):
        print("Your account number: ",self.acc_no)
        print("Your balance: ",self.bal)
        print("Time : ",current_time)
        